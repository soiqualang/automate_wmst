# automate_wmst
automate_wmst
